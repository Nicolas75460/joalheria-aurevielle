package br.com.joalheriajoiasjoia.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JoalheriaAurevielleApplicationTests {

	@Test
	void contextLoads() {
	}

}
