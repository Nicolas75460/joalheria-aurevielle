package br.com.joalheriajoiasjoia.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JoalheriaJoiasJoiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(JoalheriaJoiasJoiaApplication.class, args);
	}

}
